"""Run without graphics: python -m unittest -v test_g1_ik"""
import unittest
import numpy as np
import g1_ik_demo as demo
import g1_ik_numpy as baseline


class G1IKTests(unittest.TestCase):
    def test_models_and_pose_derivative(self):
        demo.validate_models()

    def test_numpy_geometry_matches_pinocchio(self):
        rng = np.random.default_rng(23)
        for _ in range(10):
            q = rng.uniform(demo.LOWER, demo.UPPER)
            np.testing.assert_allclose(demo.ARM.forward(q).homogeneous,
                                       baseline.forward(q)[0], atol=1e-12)

    def test_position_solvers(self):
        target = demo.ARM.forward(demo.Q_TARGET).translation.copy()
        for method in ('transpose', 'pinv', 'dls'):
            with self.subTest(method=method):
                result = demo.solve_ik(target, method=method)
                self.assertEqual(result['status'], 'converged')
                self.assertLess(result['errors'][-1], 1e-4)
                self.check_history(result)

    def test_pose_solvers(self):
        goal = demo.ARM.forward(demo.Q_TARGET)
        for method in ('pinv', 'dls'):
            with self.subTest(method=method):
                result = demo.solve_ik(goal.translation, method=method, target_rotation=goal.rotation)
                self.assertEqual(result['status'], 'converged')
                self.assertLess(result['errors'][-1], 1e-4)
                self.assertLess(result['orientation_errors'][-1], 1e-3)
                self.check_history(result)

    def check_history(self, result):
        self.assertTrue(np.all(result['history'] >= demo.LOWER))
        self.assertTrue(np.all(result['history'] <= demo.UPPER))
        self.assertTrue(np.all(np.diff(result['costs']) <= 1e-12))
        self.assertTrue(np.all(np.linalg.norm(np.diff(result['history'], axis=0), axis=1) <= 0.12+1e-12))

    def test_unreachable_target(self):
        result = demo.solve_ik([2, 2, 2])
        self.assertIn(result['status'], ('stalled', 'iteration_limit'))
        self.assertGreater(result['errors'][-1], 1.0)
        self.assertTrue(np.isfinite(result['q']).all())
        self.check_history(result)

    def test_already_reached(self):
        goal = demo.ARM.forward(demo.Q_START)
        result = demo.solve_ik(goal.translation, target_rotation=goal.rotation)
        self.assertEqual(result['status'], 'converged')
        self.assertEqual(result['iterations'], 0)

    def test_invalid_inputs(self):
        for kwargs in ({'target': [np.nan, 0, 0]}, {'target': [0, 0]},
                       {'target': [0, 0, 0], 'q0': np.zeros(6)},
                       {'target': [0, 0, 0], 'target_rotation': np.zeros((3, 3))},
                       {'target': [0, 0, 0], 'damping': 0}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                demo.solve_ik(**kwargs)

    def test_display_mapping_and_target_frame(self):
        bridge = demo.G1Viewer()
        goal = demo.ARM.forward(demo.Q_TARGET)
        bridge.data.qpos[:] = 0.1  # emulate a GUI joint edit
        bridge.update(demo.Q_START, goal.translation, goal.rotation)
        world = demo.ARM.world_T_torso * goal
        np.testing.assert_allclose(bridge.data.mocap_pos[bridge.mocap_id], world.translation)
        quat = np.zeros(9)
        bridge.mj.mju_quat2Mat(quat, bridge.data.mocap_quat[bridge.mocap_id])
        np.testing.assert_allclose(quat.reshape(3, 3), world.rotation, atol=1e-12)
        other = np.ones(bridge.model.nq, dtype=bool)
        other[bridge.iq] = False
        np.testing.assert_allclose(bridge.data.qpos[other], 0)
        self.assertEqual(bridge.data.time, 0)


if __name__ == '__main__':
    unittest.main()
