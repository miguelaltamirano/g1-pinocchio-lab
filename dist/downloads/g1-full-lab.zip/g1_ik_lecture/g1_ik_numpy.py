"""G1 left-arm position IK lesson. Dependencies: numpy, matplotlib.

Run: python g1_ik_demo.py --save g1_ik_results.png
The torso is fixed; positions are metres in torso_link, angles radians.
This is a kinematics exercise, with no robot connection or dynamics.
"""

import argparse
import numpy as np

# Extracted from Unitree's official g1_29dof.urdf; see MODEL_SOURCE below.
MODEL_SOURCE = 'https://github.com/unitreerobotics/unitree_ros/blob/9926cc2f179ae3b86f4f74087bd32ef0c8b6fd90/robots/g1_description/g1_29dof.urdf'
JOINTS = [{'name': 'left_shoulder_pitch_joint',
  'xyz': [0.0039563, 0.10022, 0.23778],
  'rpy': [0.27931, 5.4949e-05, -0.00019159],
  'axis': [0.0, 1.0, 0.0],
  'lower': -3.0892,
  'upper': 2.6704},
 {'name': 'left_shoulder_roll_joint',
  'xyz': [0.0, 0.038, -0.013831],
  'rpy': [-0.27925, 0.0, 0.0],
  'axis': [1.0, 0.0, 0.0],
  'lower': -1.5882,
  'upper': 2.2515},
 {'name': 'left_shoulder_yaw_joint',
  'xyz': [0.0, 0.00624, -0.1032],
  'rpy': [0.0, 0.0, 0.0],
  'axis': [0.0, 0.0, 1.0],
  'lower': -2.618,
  'upper': 2.618},
 {'name': 'left_elbow_joint',
  'xyz': [0.015783, 0.0, -0.080518],
  'rpy': [0.0, 0.0, 0.0],
  'axis': [0.0, 1.0, 0.0],
  'lower': -1.0472,
  'upper': 2.0944},
 {'name': 'left_wrist_roll_joint',
  'xyz': [0.1, 0.00188791, -0.01],
  'rpy': [0.0, 0.0, 0.0],
  'axis': [1.0, 0.0, 0.0],
  'lower': -1.972222054,
  'upper': 1.972222054},
 {'name': 'left_wrist_pitch_joint',
  'xyz': [0.038, 0.0, 0.0],
  'rpy': [0.0, 0.0, 0.0],
  'axis': [0.0, 1.0, 0.0],
  'lower': -1.614429558,
  'upper': 1.614429558},
 {'name': 'left_wrist_yaw_joint',
  'xyz': [0.046, 0.0, 0.0],
  'rpy': [0.0, 0.0, 0.0],
  'axis': [0.0, 0.0, 1.0],
  'lower': -1.614429558,
  'upper': 1.614429558}]


def rotation(axis, angle):
    """Rodrigues rotation about a unit axis."""
    axis = np.asarray(axis, dtype=float)
    axis = axis / np.linalg.norm(axis)
    x, y, z = axis
    K = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]])
    return np.eye(3) + np.sin(angle) * K + (1 - np.cos(angle)) * K @ K


def origin_transform(xyz, rpy):
    """URDF origin rotation is Rz(yaw) Ry(pitch) Rx(roll)."""
    r, p, y = rpy
    T = np.eye(4)
    T[:3, :3] = (rotation([0, 0, 1], y) @ rotation([0, 1, 0], p)
                 @ rotation([1, 0, 0], r))
    T[:3, 3] = xyz
    return T


ORIGINS = [origin_transform(j['xyz'], j['rpy']) for j in JOINTS]
LOWER = np.array([j['lower'] for j in JOINTS])
UPPER = np.array([j['upper'] for j in JOINTS])
# A classroom tool point 8 cm along the final wrist frame's local x axis.
# This offset is a teaching choice, not an official palm/fingertip frame.
TOOL = np.array([0.08, 0.0, 0.0])
Q_START = np.array([0.0, 0.20, 0.0, 0.60, 0.0, 0.0, 0.0])
Q_TARGET = np.array([-0.60, 0.45, 0.25, 1.20, 0.20, -0.30, 0.15])


def forward(q):
    """Return tool pose, joint origins, and joint axes in the torso frame."""
    T = np.eye(4)
    origins, axes = [], []
    for angle, joint, origin in zip(q, JOINTS, ORIGINS):
        T = T @ origin
        origins.append(T[:3, 3].copy())
        axes.append(T[:3, :3] @ joint['axis'])
        R = np.eye(4)
        R[:3, :3] = rotation(joint['axis'], angle)
        T = T @ R
    tool_pose = T.copy()
    tool_pose[:3, 3] += T[:3, :3] @ TOOL
    return tool_pose, np.array(origins), np.array(axes)


def position_jacobian(q):
    """Column i is axis_i cross (tool_position - joint_origin_i)."""
    T, origins, axes = forward(q)
    return np.cross(axes, T[:3, 3] - origins).T


def solve_ik(target, q0=Q_START, method='dls', damping=0.03,
             max_iter=400, tolerance=1e-4, max_step=0.12):
    """Local position IK. Returns history and an explicit convergence status.

    All methods share a step cap, joint clipping, and backtracking. Clipping
    is a simple teaching heuristic; it is NOT constrained least squares/QP.
    Failure means this local search failed, not that the target is infeasible.
    """
    if method not in ('transpose', 'pinv', 'dls'):
        raise ValueError('Unknown method: ' + method)
    target = np.asarray(target, dtype=float)
    q = np.clip(np.array(q0, dtype=float), LOWER, UPPER)
    errors, configurations = [], []
    status = 'iteration_limit'
    for iteration in range(max_iter + 1):
        e = target - forward(q)[0][:3, 3]
        error = np.linalg.norm(e)
        errors.append(error)
        configurations.append(q.copy())
        if error < tolerance:
            status = 'converged'
            break
        if iteration == max_iter:
            break
        J = position_jacobian(q)
        if method == 'transpose':
            # Best step along J.T @ e in the linearized least-squares problem.
            gradient = J.T @ e
            Jg = J @ gradient
            alpha = (gradient @ gradient) / max(Jg @ Jg, 1e-20)
            dq = alpha * gradient
        elif method == 'pinv':
            dq = np.linalg.pinv(J, rcond=1e-6) @ e
        else:
            dq = J.T @ np.linalg.solve(J @ J.T + damping**2 * np.eye(3), e)
        dq *= min(1.0, max_step / max(np.linalg.norm(dq), 1e-15))
        # Accept only an actual reduction in Cartesian position error.
        for scale in 0.5 ** np.arange(15):
            candidate = np.clip(q + scale * dq, LOWER, UPPER)
            if np.linalg.norm(target - forward(candidate)[0][:3, 3]) < error - 1e-13:
                q = candidate
                break
        else:
            status = 'stalled'
            break
    return dict(q=q, errors=np.array(errors), history=np.array(configurations),
                status=status, iterations=len(errors)-1)


def compare(target=None):
    # FK generates a demonstrably reachable position. The solver only receives
    # that position, not Q_TARGET; redundant IK need not recover Q_TARGET.
    if target is None:
        target = forward(Q_TARGET)[0][:3, 3]
    results = {m: solve_ik(target, method=m) for m in ('transpose', 'pinv', 'dls')}
    for method, result in results.items():
        print(f"{method:10s} {result['status']:16s} "
              f"{result['iterations']:4d} iterations; "
              f"error {result['errors'][-1]*1000:.4f} mm")
    return np.asarray(target), results


def plot_results(target, results):
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(12, 5))
    ax = fig.add_subplot(121, projection='3d')
    tracks = []
    for label, q in [('Initial', Q_START), ('DLS solution', results['dls']['q'])]:
        T, points, _ = forward(q)
        points = np.vstack((points, T[:3, 3]))
        tracks.append(points)
        ax.plot(*points.T, '-o', label=label)
    ax.scatter(*target, color='red', marker='*', s=130, label='Target tool position')
    points = np.vstack(tracks + [target[None]])
    center = (points.max(axis=0) + points.min(axis=0)) / 2
    radius = max(np.ptp(points, axis=0).max() * 0.65, 0.15)
    ax.set(xlim=(center[0]-radius, center[0]+radius),
           ylim=(center[1]-radius, center[1]+radius),
           zlim=(center[2]-radius, center[2]+radius),
           xlabel='Torso x [m]', ylabel='Torso y [m]', zlabel='Torso z [m]',
           title='G1 left arm: fixed torso, position task')
    ax.set_box_aspect([1, 1, 1])
    ax.legend(fontsize=8)
    ax2 = fig.add_subplot(122)
    for method, result in results.items():
        ax2.semilogy(result['errors'] * 1000, label=method)
    ax2.axhline(0.1, color='gray', linestyle='--', label='0.1 mm tolerance')
    ax2.set(xlabel='Iteration', ylabel='Position error [mm]', title='Same target and initial configuration')
    ax2.grid(True, which='both', alpha=0.25)
    ax2.legend()
    fig.tight_layout()
    return fig


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--save', help='Save a plot without opening a window')
    parser.add_argument('--target', type=float, nargs=3, metavar=('X', 'Y', 'Z'))
    args = parser.parse_args()
    if args.save:
        import matplotlib
        matplotlib.use('Agg')
    target, results = compare(args.target)
    fig = plot_results(target, results)
    if args.save:
        fig.savefig(args.save, dpi=160)
    else:
        import matplotlib.pyplot as plt
        plt.show()


if __name__ == '__main__':
    main()
