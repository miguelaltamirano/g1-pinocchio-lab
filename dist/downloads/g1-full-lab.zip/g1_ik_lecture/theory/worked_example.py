"""Small linear IK example: python theory/worked_example.py (NumPy only)."""
import numpy as np


def worked_example():
    J = np.diag([0.50, 0.01])  # metres / radian
    error = np.array([0.02, 0.02])  # metres
    damping = 0.05  # same units as singular values of this scaled Jacobian
    pinv_step = np.linalg.pinv(J) @ error
    dls_step = J.T @ np.linalg.solve(J @ J.T + damping**2*np.eye(2), error)
    # Verify DLS independently through its normal equations.
    expected = np.linalg.solve(J.T @ J + damping**2*np.eye(2), J.T @ error)
    np.testing.assert_allclose(pinv_step, [0.04, 2.0])
    np.testing.assert_allclose(dls_step, expected)
    print('J = diag(0.50, 0.01) m/rad; e = (0.02, 0.02) m')
    print('Pseudoinverse update [rad]:', pinv_step)
    print('DLS update [rad]:', dls_step)
    print('DLS predicted task displacement [m]:', J @ dls_step)
    print('DLS remaining linearized error [mm]:', 1000*(error-J @ dls_step))
    print('Raw updates before the G1 solver step cap and backtracking.')


if __name__ == '__main__':
    worked_example()
