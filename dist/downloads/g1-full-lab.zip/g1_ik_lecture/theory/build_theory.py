"""Instructor-only PDF builder. Requires reportlab and matplotlib; students only open the PDF."""
from pathlib import Path
import json,io,html
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parent
SOURCES={
 'MR':('Modern Robotics, Chapter 6 — numerical IK','https://modernrobotics.northwestern.edu/chapters/chapter6/'),
 'PIN':('Pinocchio — inverse kinematics example','https://gepetto.github.io/doc/pinocchio/doxygen-html/md_doc_b-examples_d-inverse-kinematics.html'),
 'G1':('Unitree — pinned G1 29-DoF URDF','https://github.com/unitreerobotics/unitree_ros/blob/9926cc2f179ae3b86f4f74087bd32ef0c8b6fd90/robots/g1_description/g1_29dof.urdf'),
 'SOT':('Stack of Tasks — humanoid hierarchical control','https://stack-of-tasks.github.io/'),
 'PINK':('Pink — differential IK with Pinocchio','https://github.com/pink-kinematics/pink'),
 'MINK':('Mink — differential IK with MuJoCo','https://github.com/kevinzakka/mink'),
 'MJ':('MuJoCo — Python and passive viewer','https://mujoco.readthedocs.io/en/stable/python.html'),
 'MOVEIT':('MoveIt — KDL and LMA solver plugins','https://moveit.picknik.ai/main/doc/examples/kinematics_configuration/kinematics_configuration_tutorial.html'),
 'TRAC':('TRAC-IK — Newton and SQP searches','https://traclabs.com/projects/trac-ik/'),
 'UNITREEIK':('Unitree — arm IK implementation','https://github.com/unitreerobotics/xr_teleoperate/blob/main/teleop/robot_control/robot_arm_ik.py')}
slides=[]
def add(title,bullets,notes,eq=(),figure=None,prompt='',refs=()):
 slides.append(dict(title=title,bullets=bullets,notes=notes,equations=list(eq),figure=figure,prompt=prompt,refs=list(refs)))
add('Inverse kinematics for humanoid robots',[
 'From a target hand pose to joint configurations.',
 'Compare three numerical solvers on the Unitree G1.',
 'Connect arm IK to constrained whole-body IK.'
],'''Audience: students with forward kinematics and basic linear algebra. Allow roughly 45 minutes for the theory, including questions, and another 45 minutes for the lab. Students should leave able to derive a local IK update, explain why damping is useful, distinguish task errors from feasibility constraints, and identify what an arm example omits from whole-body control. Show the G1 preview, then ask what quantities an IK solver receives and returns. The task here outputs joint configurations; it does not compute motor torques.''',figure='../g1_mujoco_preview.png',prompt='Input: target pose. Output: a joint configuration.',refs=('G1',))
add('IK is an inverse problem with several answers',[
 'Forward kinematics: joint configuration → task pose.',
 'IK may have no solution, one solution, or many.',
 'The starting configuration influences a local solver.'
],'''Use the planar two-link drawing as an explanatory example, not as the G1 model. Both configurations reach the same point. For a redundant arm there can be a continuous family of solutions. Reachability depends on the selected task: a reachable position does not imply that every orientation at that position is reachable. Joint limits and collisions restrict the feasible set. A local numerical failure is evidence about that run, not a proof that no solution exists.''',figure='figures/multiple_solutions.png',prompt='Can the hand reach a point but fail to reach a requested pose?',refs=('MR',))
add('The G1 task we actually solve',[
 '29-DoF model; only seven left-arm joints are active.',
 'Position task: 3 constraints, typically 4 redundant directions.',
 'Pose task: up to 6 constraints, typically 1 redundant direction.',
 'All targets use torso_link; the base and other joints are fixed.'
],'''The numerical counts assume a full-row-rank task Jacobian. At a singularity, rank can drop; describe redundancy through n minus rank(J), not only by counting requested coordinates. The teaching tool is 8 cm along the last wrist frame x axis. It is not a calibrated fingertip. The model is a pinned official 29-DoF G1 variant; do not generalize these joint counts or limits to every G1. A free-floating base would add six velocity dimensions, but our base is fixed.''',eq=(r'J_p\in\mathbb{R}^{3\times7},\qquad J_{\rm pose}\in\mathbb{R}^{6\times7}',),prompt='Why can the elbow move while the hand remains still?',refs=('G1',))
add('Which solver families should students know?',[
 'Analytical IK: geometry-specific, useful for suitable limb chains.',
 'Jacobian methods: transpose, pseudoinverse and DLS.',
 'Constrained QP / hierarchical IK: multiple tasks and limits.',
 'Nonlinear optimization: richer objectives and constraints.'
],'''This is a representative robotics taxonomy, not a measured popularity ranking. Explain the difference between an algorithm and a software package. KDL and TRAC-IK are established chain solvers; Pink and Mink build differential IK around QPs; Unitree arm code uses Pinocchio with CasADi and IPOPT. Analytical solutions can be extremely useful for suitable geometry, but do not automatically solve humanoid whole-body coupling. Mention CCD/FABRIK only as optional further reading if students know animation: they are not needed for this robotics-focused practical.''',prompt='Pinocchio supplies kinematics. Our code chooses the IK update.',refs=('MOVEIT','TRAC','PINK','MINK','UNITREEIK'))
add('Linearize the forward kinematics',[
 'Define error as desired minus current position.',
 'The Jacobian maps a small joint step to a task displacement.',
 'Recompute it after moving: the model is only locally linear.'
],'''For each revolute joint, form its axis and origin in the same reference frame as the tool point. The cross product gives a column of the position Jacobian. The angular Jacobian column is the joint axis. Students already know FK, so emphasize the local approximation and frame consistency. In G1Arm.jacobian, Pinocchio returns the tool-origin Jacobian in world-aligned axes; the code rotates both the linear and angular blocks into the fixed torso axes. A moving reference frame would require additional relative-motion terms.''',eq=(r'e=p^*-p(q),\qquad p(q+\Delta q)\approx p(q)+J(q)\Delta q',r'J_i=a_i\times(p-o_i)'),prompt='Code connection: G1Arm.forward and G1Arm.jacobian.',refs=('MR','PIN'))
add('Jacobian transpose: follow a descent direction',[
 'Minimize squared task error by moving along the gradient.',
 'Simple to implement; sensitive to step-size selection.',
 'Poor conditioning can make progress slow.'
],'''For F(q)=one half e transpose e and e=target minus current, the gradient is minus J transpose e. Therefore a positive step along J transpose e is a descent direction locally. A too-large step can increase the nonlinear error. Our implementation computes an optimal scalar along this direction for the linearized problem, then applies a step cap and backtracking. With g=J transpose e, alpha=(g transpose g)/(Jg transpose Jg), when the denominator is nonzero. That differs from a fixed-gain transpose controller; be clear about what is compared.''',eq=(r'F(q)=\frac{1}{2}\Vert e\Vert^2,\qquad \nabla F=-J^Te',r'\Delta q=\alpha J^Te'),prompt='Code connection: the transpose branch in solve_ik.',refs=('MR',))
add('Pseudoinverse: solve the local least-squares task',[
 'Find a joint update that best matches the desired displacement.',
 'Choose minimum update norm when solutions are non-unique.',
 'Small singular values amplify some joint-motion directions.'
],'''Use the singular value decomposition J=U Sigma V transpose. For each retained nonzero singular value, the pseudoinverse multiplies the corresponding task-error component by one over sigma. The minimum-norm property describes the local linear least-squares update, not a globally optimal posture or shortest nonlinear trajectory. numpy.linalg.pinv also truncates small singular values according to rcond, so the implementation is already numerically safeguarded. This does not guarantee global convergence.''',eq=(r'\Delta q=J^+e,\qquad J=U\Sigma V^T',r'J^+=V\Sigma^+U^T'),prompt='What happens when a required motion direction becomes difficult?',refs=('MR',))
add('Singularities: task directions become unavailable',[
 'A singularity is a loss of task-Jacobian rank.',
 'Near a singularity, a small task step can demand a large joint step.',
 'Damping reduces amplification; it cannot create a missing direction.'
],'''Distinguish a singular configuration from a joint at its limit. Either can cause trouble, but they are different phenomena. The plotted pseudoinverse gain tends to infinity as a nonzero singular value approaches zero; the exact pseudoinverse sets an exactly zero singular value to zero, and software truncates below a threshold. Thus the curve illustrates the amplification of retained near-zero values, not the value at sigma=0. DLS has bounded gain and suppresses poorly controllable directions. Ask students to inspect actual singular values instead of assuming the G1 zero posture is singular.''',figure='figures/damping_gain.png',prompt='Rank loss and joint limits are different issues.',refs=('PIN',))
add('Damped least squares: penalize large updates',[
 'Add a quadratic cost on the joint increment.',
 'Small damping follows the task closely; larger damping is conservative.',
 'Fixed-damping DLS is related to, but not identical to, full adaptive LM.'
],'''Derive the normal equations by differentiating the regularized objective: (J transpose J + lambda squared I) delta q = J transpose e. For positive lambda, the equivalent task-space expression uses a 3 by 3 or 6 by 6 system in this lesson. In code use np.linalg.solve, not an explicit matrix inverse. The lambda choice depends on task scaling and units. Full Levenberg-Marquardt methods adapt damping using the agreement between a local model and actual improvement; our code uses fixed damping plus backtracking. Damping improves conditioning, not global feasibility.''',eq=(r'\min_{\Delta q}\ \Vert J\Delta q-e\Vert^2+\lambda^2\Vert\Delta q\Vert^2',r'\Delta q=J^T(JJ^T+\lambda^2I)^{-1}e'),prompt='Code connection: the dls branch; damping defaults to 0.03.',refs=('PIN',))
add('A small worked example exposes the tradeoff',[
 'Let J = diag(0.50, 0.01) m/rad and e = (0.02, 0.02) m.',
 'Pseudoinverse: Δq = (0.0400, 2.0000) rad.',
 'DLS with λ = 0.05 m/rad: Δq ≈ (0.0396, 0.0769) rad.',
 'DLS sacrifices immediate motion in the poorly conditioned direction.'
],'''These are raw updates before step caps or backtracking, for a deliberately simple two-dimensional linear task. The pseudoinverse predicts a displacement of (0.02,0.02) m. DLS predicts about (0.019802,0.000769) m, leaving about 19.23 mm of the second error component. The second pseudoinverse joint step is 2 rad, which may be unacceptable for a single local update. This example makes the accuracy-versus-update-size tradeoff visible. Ask students to compute the two scalar gains and to discuss what changing metres to millimetres would require for lambda. Values are calculated by the provided worked_example.py.''',prompt='DLS reduces update size; it does not make the difficult direction easy.')
add('Orientation requires a consistent residual',[
 'Position and orientation form a six-dimensional pose task.',
 'Use a rotation logarithm instead of subtracting Euler angles.',
 'Scale metres and radians deliberately.',
 'Use the log-map derivative for a finite orientation error.'
],'''In our implementation E=R_target R_current transpose and e_R=log3(E), expressed in the torso frame. The geometric angular Jacobian maps joint increments to spatial angular motion in that same frame. Pinocchio Jlog3 is the right log derivative: the negative residual derivative is Jlog3(E) J_omega. task() stacks this block, multiplied by ell, below the position Jacobian. ell=0.20 m/rad sets the relative influence of orientation in the cost. Position and orientation convergence are checked separately: 0.1 mm and 0.001 rad. The rotation logarithm has branch issues near pi; do not describe it as a globally smooth coordinate chart.''',eq=(r'e_R=\operatorname{Log}(R^*R^T)^\vee',r'e_s=[e_p;\ \ell e_R],\qquad \ell=0.20\ {\rm m/rad}'),prompt='Code connection: task(); run with --pose.',refs=('PIN',))
add('Redundancy permits secondary objectives',[
 'Use remaining freedom for posture or joint-limit avoidance.',
 'A null-space motion preserves the primary task to first order.',
 'Finite steps, damping and clipping can weaken that preservation.'
],'''For the Moore-Penrose inverse, N=I-J_plus J is a projector into the Jacobian null space, giving JN=0. A secondary posture direction z=beta(q_rest-q) can be added. This does not guarantee exact preservation after a finite nonlinear step, so recompute FK and the Jacobian. With a damped inverse, I-J_sharp J is generally not an exact null-space projector. Clipping individual joints can also destroy the cancellation. The notebook demonstrates the first-order property; the main IK solver intentionally leaves the posture term as a student extension.''',eq=(r'\Delta q=J^+e+(I-J^+J)z',r'z=\beta(q_{\rm rest}-q)'),prompt='Code connection: the notebook null-space experiment.',refs=('MR','SOT'))
add('Limits and stopping conditions are part of the method',[
 'Joint bounds, velocity bounds and collision constraints are distinct.',
 'Clipping keeps joint angles in range but may stall the task.',
 'Report residuals and status: converged, stalled, or iteration limit.',
 'Use the same initialization and safeguards for comparisons.'
],'''Our solver bounds the norm of an update to 0.12 rad, clips the candidate joint angles, and accepts only a lower scaled task cost. The 0.12-rad cap is a numerical increment cap, not a certified velocity limit: iteration speed is not the same as a physical time step. Backtracking improves local behavior but does not eliminate local minima. An unreachable target should not be reported as successful merely because an array of angles was returned. Compare final position error, orientation error, iteration count, success rate across targets, and optionally timing on the same machine. One target cannot establish universal superiority.''',prompt='Code connection: solve_ik history, status and backtracking loop.',refs=('PINK',))
add('Whole-body differential IK as a quadratic program',[
 'Optimize generalized velocity for several simultaneous tasks.',
 'Represent support contacts as equalities when feasible.',
 'Apply joint and velocity bounds as inequalities.',
 'Integrate the result over a chosen control time step.'
],'''Here e_i is desired minus current task value, K_i maps error into desired task velocity, and W_i scales task components. Add a posture velocity objective if useful. For an already satisfied fixed contact, J_c v=0 enforces zero contact velocity; a contact-error stabilization term is needed if the constraint has drifted. The joint-position bound is a one-step linear constraint on actuated scalar joints only. For a floating base, use manifold integration; quaternion configuration coordinates and generalized velocity have different dimensions. With v dimension 35 for a 29-actuator floating humanoid, a position-plus-quaternion base representation gives 36 configuration coordinates. This exercise keeps the base fixed and does not implement this whole-body QP.''',eq=(r'\min_v\ \sum_i\Vert W_i(J_i v-K_i e_i)\Vert^2+\mu\Vert v\Vert^2',r'J_c v=0,\qquad q_{\min}\leq q_a+\Delta t\,v_a\leq q_{\max}'),prompt='Also constrain v_a to the actuated joint velocity limits.',refs=('PINK','MINK','SOT'))
add('Priorities and balance require explicit choices',[
 'Hard constraints must be satisfied or declared infeasible.',
 'Weighted tasks trade errors; large weights are not strict priorities.',
 'A hierarchy can place feet above hands and posture.',
 'Kinematic feasibility does not establish dynamic balance.'
],'''An illustrative design is: hard support/contact and joint constraints, then a feasible center-of-mass task, then reaching, then posture. This is not a universal priority ordering. Hierarchical optimization preserves higher-priority optima subject to numerical tolerances, while weighted least squares permits tradeoffs. Conflicting hard constraints can make a problem infeasible. For coplanar static contacts under suitable force assumptions, projected COM in the support polygon is a useful quasi-static criterion. Dynamic motion also requires force, friction, momentum and torque considerations. IK does not replace inverse dynamics or a stabilizing controller.''',prompt='If a hand target requires lifting a support foot, which task should yield?',refs=('SOT','PINK'))
add('How the theory maps to the provided code',[
 'G1Arm: reduced Pinocchio model, FK and Jacobians.',
 'task: frame-consistent position / pose error and derivative.',
 'solve_ik: update law, safeguards and convergence status.',
 'G1Viewer: named joint mapping and MuJoCo visualization.'
],'''Walk through one iteration: get the current configuration; calculate the task error and Jacobian; test tolerances; choose an update; cap the step; apply joint bounds with backtracking; repeat. The viewer writes named arm joint coordinates and calls mj_forward, never mj_step. Pinocchio and MuJoCo use the same original geometry, and model cross-checks compare poses and Jacobians. Translating a torso-frame target to world coordinates and distinguishing q indices from velocity indices are important implementation details. All non-arm joints are restored to their reference configuration on display updates.''',prompt='Run python g1_ik_demo.py --check before the live demonstration.',refs=('PIN','MJ'))
add('A measured result, not a universal ranking',[
 'Same supplied position target and initial configuration.',
 'Transpose: 251 iterations; pseudoinverse: 8; DLS: 9.',
 'All meet the 0.1 mm position tolerance.',
 'Damping helps conditioning; it need not reduce iteration count.'
],'''These are measured results from the provided position-only example and its particular safeguards. Final errors are approximately 0.0984 mm for transpose, 0.0007 mm for pseudoinverse and 0.0687 mm for DLS. They stop at different residuals because of discrete updates. The plot shows scaled task error; for a position-only task this equals the position-error norm. In pose mode the default transpose run reaches its 400-iteration limit while pseudoinverse and DLS converge. Show that honest failure status is a useful result. Do not compare these iteration counts as wall-clock speed or a benchmark of unrelated library solvers.''',figure='../g1_ik_results.png',prompt='Evidence: the executed notebook and validation.json.')
add('The 45-minute practical',[
 '0–10 min: open viewer, move target, switch solvers.',
 '10–20 min: inspect update code and change damping.',
 '20–30 min: compare position and pose; test unreachable targets.',
 '30–45 min: null-space exercise and whole-body discussion.'
],'''Use I/K, J/L and U/O to move the target along torso x, y and z. Keys 1, 2, 3 switch methods and reset the arm; Space resets the arm and target. Start with the numerical comparison if the viewer is unavailable. Suggested terminal commands: python g1_ik_demo.py; python g1_ik_demo.py --pose; python g1_ik_demo.py --save result.png; python g1_ik_demo.py --target 2 2 2 --save unreachable.png. On macOS use mjpython for the interactive viewer. The numerical notebook works without a desktop graphics context; the supplied image provides a visual reference.''',prompt='Have students predict the result before changing each parameter.')
add('Questions to check understanding',[
 'Why does a seven-joint arm have different redundancy for position and pose?',
 'Why can pseudoinverse produce large joint increments?',
 'Why can clipping break a null-space objective?',
 'Why does an IK solution not prove that a humanoid can balance?'
],'''Expected answers: at full task rank, nullity is 7-3=4 for position and 7-6=1 for pose; small retained singular values have large reciprocal gain; clipping changes the coordinated joint update and therefore can destroy J delta q=0; kinematics alone does not check contact force feasibility, friction, momentum or actuation. Follow up with two questions: Does failed local search prove unreachable? No. Does large task weight guarantee strict priority? No. Students should connect these answers to error plots and statuses observed in the lab.''',prompt='Exit task: justify a solver and a task hierarchy for a two-handed reach.')
add('References and teaching files',[
 'Slides: theory/ik_theory_slides.pdf',
 'Instructor notes: theory/instructor_notes.txt',
 'Executable lecture: g1_ik_lecture.ipynb',
 'Demo: g1_ik_demo.py • Setup: README.txt'
],'''The presentation is an original synthesis for this G1 exercise. Follow the linked primary sources for the underlying theory and library details. Model provenance and the Unitree license are bundled. The numerical worked example is reproducible using python theory/worked_example.py. The PDF builder is instructor tooling and is not needed on student laptops; it requires ReportLab in addition to Matplotlib.''',refs=tuple(SOURCES))


def paragraph(c,text,x,y,width,size=20,color='#18354b',leading=None):
    style=ParagraphStyle('body',fontName='DejaVu',fontSize=size,leading=leading or size*1.36,textColor=HexColor(color))
    p=Paragraph(html.escape(text),style);w,h=p.wrap(width,1000)
    p.drawOn(c,x,y-h)
    return h


def render():
    fontdir=Path(matplotlib.get_data_path())/'fonts/ttf'
    pdfmetrics.registerFont(TTFont('DejaVu',str(fontdir/'DejaVuSans.ttf')))
    pdfmetrics.registerFont(TTFont('DejaVuBold',str(fontdir/'DejaVuSans-Bold.ttf')))
    pdf=ROOT/'ik_theory_slides.pdf'
    c=canvas.Canvas(str(pdf),pagesize=(960,540))
    c.setTitle('Inverse Kinematics for Humanoid Robots — Unitree G1')
    c.setAuthor('G1 robotics teaching materials')
    for number,s in enumerate(slides,1):
        c.setFillColor(HexColor('#f7f9fb'));c.rect(0,0,960,540,fill=1,stroke=0)
        c.setFillColor(HexColor('#167c80'));c.rect(0,510,960,30,fill=1,stroke=0)
        c.setFillColor(HexColor('#ffffff'));c.setFont('DejaVu',10)
        c.drawString(38,520,'HUMANOID ROBOTICS  /  INVERSE KINEMATICS  /  UNITREE G1')
        c.setFillColor(HexColor('#17324d'));c.setFont('DejaVuBold',26)
        title=s['title']
        while pdfmetrics.stringWidth(title,'DejaVuBold',26)>884:
            # Two-line titles are handled by the paragraph renderer.
            break
        paragraph(c,title,38,480,884,size=26,leading=32)
        y=415; width=420 if s['figure'] else 865
        size=17 if s['figure'] else 20
        for b in s['bullets']:
            c.setFillColor(HexColor('#167c80'));c.circle(43,y-10,3,fill=1,stroke=0)
            height=paragraph(c,b,58,y,width-18,size=size)
            y-=height+17
        if s['figure']:
            path=ROOT/s['figure']
            from PIL import Image
            with Image.open(path) as im: w,h=im.size
            maxw,maxh=445,305
            ratio=min(maxw/w,maxh/h)
            c.drawImage(str(path),x=490+(maxw-w*ratio)/2,y=110+(maxh-h*ratio)/2,
                        width=w*ratio,height=h*ratio,mask='auto')
        elif s['equations']:
            # Keep formulas below the text, above the discussion prompt.
            for k,eq in enumerate(s['equations']):
                fig=plt.figure(figsize=(9,0.7),facecolor='#f7f9fb')
                fig.text(.5,.5,'$'+eq+'$',fontsize=22,ha='center',va='center',color='#167c80')
                b=io.BytesIO();fig.savefig(b,format='png',dpi=180,bbox_inches='tight',pad_inches=.12);plt.close(fig);b.seek(0)
                image=ImageReader(b);w,h=image.getSize();r=min(850/w,55/h)
                yy=143+(len(s['equations'])-1-k)*64
                c.drawImage(image,480-w*r/2,yy-h*r/2,width=w*r,height=h*r,mask='auto')
        if s['prompt']:
            paragraph(c,s['prompt'],38,77,884,size=12,color='#167c80')
        refs=s['refs']
        if number==len(slides):
            # Compact linked bibliography, two columns.
            for i,key in enumerate(refs):
                col=i//5;row=i%5;x=42+col*450;yy=175-row*23
                label=SOURCES[key][0]
                c.setFillColor(HexColor('#167c80'));c.setFont('DejaVu',10)
                c.drawString(x,yy,label)
                c.linkURL(SOURCES[key][1],(x,yy-2,x+430,yy+13),relative=0)
        else:
            xx=38
            for key in refs:
                label='['+key+']';w=pdfmetrics.stringWidth(label,'DejaVu',9)
                c.setFillColor(HexColor('#65778a'));c.setFont('DejaVu',9);c.drawString(xx,26,label)
                c.linkURL(SOURCES[key][1],(xx,24,xx+w,38),relative=0);xx+=w+12
        c.setFillColor(HexColor('#65778a'));c.setFont('DejaVu',10);c.drawRightString(922,26,f'{number:02d} / {len(slides)}')
        c.showPage()
    c.save()
    (ROOT/'slides_source.json').write_text(json.dumps({'slides':slides,'references':SOURCES},indent=2,ensure_ascii=False)+'\n')
    notes=['INSTRUCTOR NOTES: HUMANOID IK WITH UNITREE G1','45 minutes theory + 45 minutes practical.','Prerequisites: forward kinematics, Python and linear algebra.','']
    for i,s in enumerate(slides,1):
        notes.extend([f"SLIDE {i:02d}: {s['title']}",'',s['notes'],''])
        if s['equations']: notes.extend(['Equations (LaTeX notation):',*s['equations'],''])
        if s['prompt']:notes.extend(['Discussion prompt: '+s['prompt'],''])
        if s['refs']:notes.extend(['References: '+', '.join(s['refs']),''])
    notes.extend(['PRIMARY REFERENCES',''])
    for key,(label,url) in SOURCES.items():notes.extend([key+': '+label,url,''])
    (ROOT/'instructor_notes.txt').write_text('\n'.join(notes))
    print('Created',pdf,'with',len(slides),'slides and instructor notes.')


if __name__=='__main__':render()
