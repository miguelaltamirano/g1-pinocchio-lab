G1 IK LECTURE: PINOCCHIO + MUJOCO

Extract the entire ZIP; keep models/ beside the Python files. Models and meshes
are included, so runtime needs no downloads. The full G1 is drawn; only the
seven-joint left arm moves. Base, waist, legs and right arm are fixed. This is
kinematic visualization: no physics stepping, balance control, collision checks
or robot connection.

STUDENT INSTALLATION

For a class with Windows/macOS/Linux, start with STUDENT_SETUP.txt and the
Miniforge/Conda environment.yml. This avoids pip-specific native dependencies.
That route is documented but has not been tested here. The pinned pin==3.9.0
pip release is Linux-only; the instructions below are the tested Linux route.

LINUX PIP INSTALL (tested: Python 3.10, Linux x86-64)

    python -m venv .venv

Activate on Linux:
    source .venv/bin/activate

    python -m pip install --upgrade pip
    python -m pip install --only-binary=:all: -r requirements.txt
    python g1_ik_demo.py --check

Use a compatible Python 3.10/3.11 Linux environment. Windows/macOS should use
the Conda route in STUDENT_SETUP.txt. --only-binary prevents source compilation;
if a matching wheel
is unavailable, use a supported environment or the NumPy fallback below.
The robotics distribution is named pin, imported as pinocchio. The URDF parser
and TinyXML versions are pinned because newer transitive versions caused a
missing liburdfdom_sensor.so.4.0 import error in the clean installation test.
The supplied .venv on the preparation machine is NOT included in the ZIP.

INTERACTIVE VIEWER

Linux/Windows:
    python g1_ik_demo.py
macOS (required launcher for the passive viewer):
    mjpython g1_ik_demo.py

With the window focused:
    I / K : move target +/- torso x, 2 cm
    J / L : move target +/- torso y
    U / O : move target +/- torso z
    1 / 2 / 3 : transpose / pseudoinverse / DLS, resetting the arm
    Space : reset arm and target
    Mouse : MuJoCo's camera orbit/zoom controls
    Close the window to exit

Orange marker = target; green marker = tool. Terminal output reports success,
stalling or iteration limits. Positions are metres relative to torso_link.

    python g1_ik_demo.py --pose
    python g1_ik_demo.py --method dls --damping 0.03 --target 0.25 0.25 0.05

--pose additionally matches Q_TARGET's orientation, holding that orientation
while you translate the target. Orientation errors are rotation vectors with
an exact log-map derivative and a 0.20 m/rad scaling in the objective.

HEADLESS EXPERIMENTS

    python g1_ik_demo.py --save g1_ik_results.png
    python g1_ik_demo.py --pose --save g1_pose_results.png
    python g1_ik_demo.py --check
    python -m unittest -v test_g1_ik

Comparisons use common fixed settings, including damping 0.03. --method and
--damping control the interactive viewer. --method also selects the comparison
result shown in an optional offscreen render:
    python g1_ik_demo.py --render my_g1.png
Supported Linux headless graphics can select EGL before starting Python:
    MUJOCO_GL=egl python g1_ik_demo.py --render my_g1.png
Numerical checks and Matplotlib file plots need no OpenGL context.

NOTEBOOK AND FALLBACK

Open g1_ik_lecture.ipynb in an existing Jupyter/VS Code environment and select
the Python environment containing these dependencies. Run from this folder.
Jupyter is optional and not installed by requirements.txt. For Colab, upload
and extract the WHOLE ZIP, install dependencies in the hosted runtime, and use
the extracted folder as the working directory. The desktop viewer cannot open
in Colab: use the numerical experiments and the bundled preview image there.

The original NumPy implementation is retained as g1_ik_numpy.py:
    python -m pip install numpy matplotlib
    python g1_ik_numpy.py --save numpy_comparison.png

IMPLEMENTATION AND MODEL SOURCE

Both libraries use models derived from the same official Unitree URDF. Joint
configuration and velocity indices are mapped separately by name. All other
joints are locked. The tool frame is 8 cm along the last wrist frame's x axis,
a teaching offset, not a calibrated palm/fingertip. Methods share joint-limit
clipping, a step cap and backtracking. Clipping is not a constrained QP, and
local failure does not prove infeasibility. Transpose may hit the iteration
limit for the full-pose task; this is reported explicitly.

Instructor-only model rebuild, unnecessary for students:
    python prepare_models.py

This adds a fixed base at z=0.793 m and a tool frame, removes collision geometry,
retains visual meshes, and generates a scene with floor, target and zero gravity.
Transforms are restored at full precision after MuJoCo's XML export. See
models/provenance.json for the pinned revision and checksums and
models/UNITREE_LICENSE.txt for the upstream BSD license.

Tested: eight numerical/integration tests; all notebook code cells; an actual
viewer launch, convergence and close; and offscreen rendering. See
validation.json for the measured errors and environment. The model and script
are educational kinematics code, not a dynamics controller.

References:
https://stack-of-tasks.github.io/pinocchio/download.html
https://mujoco.readthedocs.io/en/stable/python.html
https://github.com/unitreerobotics/unitree_ros/blob/9926cc2f179ae3b86f4f74087bd32ef0c8b6fd90/robots/g1_description/g1_29dof.urdf

THEORETICAL LECTURE MATERIALS

Start with theory/ik_theory_slides.pdf: 20 slides for approximately 45 minutes.
Use theory/instructor_notes.txt for explanations, questions and expected answers.
The notebook now includes the derivations and a reproducible numerical example:
    python theory/worked_example.py

Topics: local linearization, transpose/pseudoinverse/DLS, singularities, pose
residuals, redundancy, joint limits, constrained whole-body IK and task priorities.
Follow with the 45-minute practical. The slides and notes link concepts directly
to G1Arm.jacobian, task, solve_ik and G1Viewer. The PDF opens without installing
additional software packages. ReportLab is needed only by the instructor if
rebuilding slides with theory/build_theory.py; it is not a student dependency.
