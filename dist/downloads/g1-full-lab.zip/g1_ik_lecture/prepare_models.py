"""Rebuild classroom models from the bundled, unmodified Unitree URDF.

Run only when changing the model: python prepare_models.py
This keeps Pinocchio and MuJoCo on exactly the same geometry and limits.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import mujoco
import numpy as np
import pinocchio as pin

ROOT = Path(__file__).resolve().parent / 'models'


def prepare():
    tree = ET.parse(ROOT / 'g1_original.urdf')
    robot = tree.getroot()
    compiler = robot.find('mujoco/compiler')
    compiler.set('meshdir', 'meshes')
    compiler.set('discardvisual', 'false')
    compiler.set('fusestatic', 'false')
    ET.SubElement(robot, 'link', name='world')
    joint = ET.SubElement(robot, 'joint', name='classroom_fixed_base', type='fixed')
    ET.SubElement(joint, 'parent', link='world')
    ET.SubElement(joint, 'child', link='pelvis')
    ET.SubElement(joint, 'origin', xyz='0 0 0.793', rpy='0 0 0')
    # The hand frame is a deliberate classroom tool offset, not a measured palm.
    ET.SubElement(robot, 'link', name='left_tool')
    joint = ET.SubElement(robot, 'joint', name='left_tool_fixed', type='fixed')
    ET.SubElement(joint, 'parent', link='left_wrist_yaw_link')
    ET.SubElement(joint, 'child', link='left_tool')
    ET.SubElement(joint, 'origin', xyz='0.08 0 0', rpy='0 0 0')
    # Visualization-only model: remove collision geoms so only the visual mesh
    # is drawn. This exercise never steps physics or checks collisions.
    for link in robot.findall('link'):
        for collision in link.findall('collision'):
            link.remove(collision)
    ET.indent(tree)
    urdf = ROOT / 'g1_classroom.urdf'
    tree.write(urdf, encoding='unicode')
    model = mujoco.MjModel.from_xml_path(str(urdf))
    xml = ROOT / 'g1_classroom.xml'
    mujoco.mj_saveLastXML(str(xml), model)
    scene = ET.parse(xml)
    root = scene.getroot()
    root.find('compiler').set('meshdir', 'meshes')
    # mj_saveLastXML formats transforms with limited precision. Restore the
    # original URDF transforms at float64 precision to preserve cross-backend FK.
    for joint in robot.findall('joint'):
        child = joint.find('child').get('link')
        body = root.find(f".//body[@name='{child}']")
        if body is None:
            raise ValueError('Expected retained URDF link: '+child)
        origin = joint.find('origin')
        xyz = origin.get('xyz', '0 0 0') if origin is not None else '0 0 0'
        rpy = origin.get('rpy', '0 0 0') if origin is not None else '0 0 0'
        R = pin.rpy.rpyToMatrix(np.fromstring(rpy, sep=' '))
        xyzw = pin.Quaternion(R).coeffs()
        body.set('pos', xyz)
        body.set('quat', ' '.join(format(v, '.17g') for v in xyzw[[3, 0, 1, 2]]))
        mj_joint = body.find('joint')
        if mj_joint is not None:
            mj_joint.set('axis', joint.find('axis').get('xyz'))
            limits = joint.find('limit')
            mj_joint.set('range', limits.get('lower')+' '+limits.get('upper'))
    ET.SubElement(root, 'option', gravity='0 0 0')
    visual = ET.SubElement(root, 'visual')
    ET.SubElement(visual, 'global', offwidth='1280', offheight='960')
    world = root.find('worldbody')
    ET.SubElement(world, 'light', pos='1 -1 3', dir='-0.3 0.3 -1', diffuse='0.8 0.8 0.8')
    ET.SubElement(world, 'light', pos='-1 1 2', dir='0.3 -0.3 -1', diffuse='0.5 0.5 0.5')
    ET.SubElement(world, 'geom', name='floor', type='plane', size='2 2 0.05',
                  rgba='0.22 0.25 0.29 1', contype='0', conaffinity='0')
    tool = root.find(".//body[@name='left_tool']")
    ET.SubElement(tool, 'site', name='left_tool_site', size='0.013', rgba='0.1 1 0.4 1')
    target = ET.SubElement(world, 'body', name='target', mocap='true')
    ET.SubElement(target, 'geom', name='target_ball', type='sphere', size='0.023',
                  rgba='1 0.25 0.12 0.65', contype='0', conaffinity='0')
    for name, end, color in [('x', '0.09 0 0', '1 0.15 0.15 1'),
                             ('y', '0 0.09 0', '0.15 1 0.15 1'),
                             ('z', '0 0 0.09', '0.15 0.4 1 1')]:
        ET.SubElement(target, 'site', name='target_'+name, type='capsule',
                      fromto='0 0 0 '+end, size='0.003', rgba=color)
    ET.indent(scene)
    scene.write(xml, encoding='unicode')
    check = mujoco.MjModel.from_xml_path(str(xml))
    print(f'Prepared {urdf.name} and {xml.name}: {check.nq} scalar joint coordinates')


if __name__ == '__main__':
    prepare()
