"""G1 IK classroom: Pinocchio kinematics and a MuJoCo kinematic viewer.

python g1_ik_demo.py                         # interactive viewer
python g1_ik_demo.py --pose                  # position + orientation task
python g1_ik_demo.py --save convergence.png  # headless solver comparison
python g1_ik_demo.py --check                 # validate both model backends
macOS viewer: use mjpython instead of python.
"""
import argparse
from pathlib import Path
import queue
import time
import numpy as np
import pinocchio as pin

MODEL_DIR = Path(__file__).resolve().parent / 'models'
MODEL_SOURCE = 'https://github.com/unitreerobotics/unitree_ros/blob/9926cc2f179ae3b86f4f74087bd32ef0c8b6fd90/robots/g1_description/g1_29dof.urdf'
JOINT_NAMES = [f'left_{name}_joint' for name in (
    'shoulder_pitch', 'shoulder_roll', 'shoulder_yaw', 'elbow',
    'wrist_roll', 'wrist_pitch', 'wrist_yaw')]
Q_START = np.array([0.0, 0.20, 0.0, 0.60, 0.0, 0.0, 0.0])
Q_TARGET = np.array([-0.60, 0.45, 0.25, 1.20, 0.20, -0.30, 0.15])


class G1Arm:
    """Fixed-base model, reduced to seven active arm joints.

    Public q vectors always follow JOINT_NAMES. Targets are in torso_link.
    Pinocchio configuration indices and velocity indices are mapped separately.
    """
    def __init__(self):
        full = pin.buildModelFromUrdf(str(MODEL_DIR / 'g1_classroom.urdf'))
        locked = [i for i in range(1, full.njoints) if full.names[i] not in JOINT_NAMES]
        self.model = pin.buildReducedModel(full, locked, pin.neutral(full))
        self.data = self.model.createData()
        self.jids = [self.model.getJointId(name) for name in JOINT_NAMES]
        if any(j == self.model.njoints for j in self.jids):
            raise ValueError('An arm joint is missing from the Pinocchio model')
        if any(self.model.joints[j].nq != 1 or self.model.joints[j].nv != 1 for j in self.jids):
            raise ValueError('This lesson expects scalar revolute arm joints')
        self.iq = np.array([self.model.joints[j].idx_q for j in self.jids])
        self.iv = np.array([self.model.joints[j].idx_v for j in self.jids])
        self.lower = self.model.lowerPositionLimit[self.iq].copy()
        self.upper = self.model.upperPositionLimit[self.iq].copy()
        self.tool_id = self.model.getFrameId('left_tool')
        self.torso_id = self.model.getFrameId('torso_link')
        pin.framesForwardKinematics(self.model, self.data, pin.neutral(self.model))
        self.world_T_torso = self.data.oMf[self.torso_id].copy()

    def configuration(self, q):
        q = np.asarray(q, dtype=float)
        if q.shape != (7,) or not np.isfinite(q).all():
            raise ValueError('q must contain seven finite joint angles in radians')
        result = pin.neutral(self.model)
        result[self.iq] = q
        return result

    def forward(self, q):
        pin.framesForwardKinematics(self.model, self.data, self.configuration(q))
        return self.world_T_torso.actInv(self.data.oMf[self.tool_id])

    def jacobian(self, q):
        J = pin.computeFrameJacobian(self.model, self.data, self.configuration(q),
                                     self.tool_id, pin.ReferenceFrame.LOCAL_WORLD_ALIGNED)
        # Pinocchio orders spatial motion as linear then angular. The reference
        # point is the tool origin; rotate both blocks into the fixed torso frame.
        R = self.world_T_torso.rotation.T
        return np.vstack((R @ J[:3, self.iv], R @ J[3:, self.iv]))

    def points(self, q):
        pose = self.forward(q)
        inverse = self.world_T_torso.inverse()
        points = [inverse.act(self.data.oMi[j].translation) for j in self.jids]
        return np.vstack((points, pose.translation))


ARM = G1Arm()
LOWER, UPPER = ARM.lower, ARM.upper


def task(q, target, target_rotation=None, orientation_scale=0.20):
    """Return scaled residual and its NEGATIVE derivative, all in torso axes.

    The orientation residual is Log(R_target R_current.T). Jlog3 supplies its
    exact local derivative. orientation_scale [m/rad] sets the task tradeoff.
    """
    pose = ARM.forward(q)
    e_position = target - pose.translation
    J = ARM.jacobian(q)
    if target_rotation is None:
        return e_position, J[:3], np.linalg.norm(e_position), 0.0
    E = target_rotation @ pose.rotation.T
    e_rotation = pin.log3(E)
    residual = np.r_[e_position, orientation_scale * e_rotation]
    jacobian = np.vstack((J[:3], orientation_scale * pin.Jlog3(E) @ J[3:]))
    return residual, jacobian, np.linalg.norm(e_position), np.linalg.norm(e_rotation)


def solve_ik(target, q0=Q_START, method='dls', damping=0.03,
             max_iter=400, tolerance=1e-4, max_step=0.12,
             target_rotation=None, orientation_tolerance=1e-3, orientation_scale=0.20):
    """Explicit Jacobian IK: transpose, pseudoinverse, or damped least squares.

    Joint clipping, a step cap, and backtracking are teaching safeguards, not a
    constrained QP. A stalled/iteration_limit result is not proof of infeasibility.
    """
    if method not in ('transpose', 'pinv', 'dls'):
        raise ValueError('Unknown method: '+method)
    target = np.asarray(target, dtype=float)
    if target.shape != (3,) or not np.isfinite(target).all():
        raise ValueError('target must be three finite coordinates in torso_link')
    if damping < 0 or (method == 'dls' and damping == 0):
        raise ValueError('DLS needs positive damping')
    if max_iter < 0 or max_step <= 0 or tolerance <= 0 or orientation_tolerance <= 0 or orientation_scale <= 0:
        raise ValueError('Iteration count must be nonnegative; scales and tolerances positive')
    if target_rotation is not None:
        target_rotation = np.asarray(target_rotation, dtype=float)
        if (target_rotation.shape != (3, 3) or not np.isfinite(target_rotation).all()
                or not np.allclose(target_rotation.T @ target_rotation, np.eye(3), atol=1e-7)
                or not np.isclose(np.linalg.det(target_rotation), 1.0)):
            raise ValueError('target_rotation must be a proper 3x3 rotation matrix')
    ARM.configuration(q0)  # validate before clipping
    q = np.clip(np.array(q0, dtype=float), LOWER, UPPER)
    errors, angles, costs, history = [], [], [], []
    status = 'iteration_limit'
    for iteration in range(max_iter+1):
        e, J, position_error, angle_error = task(q, target, target_rotation, orientation_scale)
        cost = np.linalg.norm(e)
        errors.append(position_error); angles.append(angle_error)
        costs.append(cost); history.append(q.copy())
        if position_error < tolerance and angle_error < orientation_tolerance:
            status = 'converged'
            break
        if iteration == max_iter:
            break
        if method == 'transpose':
            gradient = J.T @ e
            Jg = J @ gradient
            alpha = (gradient @ gradient) / max(Jg @ Jg, 1e-20)
            dq = alpha * gradient
        elif method == 'pinv':
            dq = np.linalg.pinv(J, rcond=1e-6) @ e
        else:
            dq = J.T @ np.linalg.solve(J @ J.T + damping**2 * np.eye(len(e)), e)
        dq *= min(1.0, max_step / max(np.linalg.norm(dq), 1e-15))
        for scale in 0.5 ** np.arange(15):
            candidate = np.clip(q + scale*dq, LOWER, UPPER)
            trial = task(candidate, target, target_rotation, orientation_scale)[0]
            if np.linalg.norm(trial) < cost - 1e-13:
                q = candidate
                break
        else:
            status = 'stalled'
            break
    return dict(q=q, errors=np.array(errors), orientation_errors=np.array(angles),
                costs=np.array(costs), history=np.array(history), status=status,
                iterations=len(history)-1)


def compare(target=None, target_rotation=None):
    if target is None:
        target = ARM.forward(Q_TARGET).translation.copy()
    results = {m: solve_ik(target, method=m, target_rotation=target_rotation)
               for m in ('transpose', 'pinv', 'dls')}
    for method, result in results.items():
        print(f"{method:10s} {result['status']:16s} {result['iterations']:4d} iterations; "
              f"position {1000*result['errors'][-1]:.4f} mm; "
              f"orientation {np.rad2deg(result['orientation_errors'][-1]):.4f} deg")
    return np.asarray(target), results


def plot_results(target, results):
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(12, 5))
    ax = fig.add_subplot(121, projection='3d')
    tracks = []
    for label, q in [('Initial', Q_START), ('DLS solution', results['dls']['q'])]:
        points = ARM.points(q)
        tracks.append(points)
        ax.plot(*points.T, '-o', label=label)
    ax.scatter(*target, color='red', marker='*', s=130, label='Target')
    points = np.vstack(tracks + [target[None]])
    center = (points.max(axis=0)+points.min(axis=0))/2
    radius = max(np.ptp(points, axis=0).max()*0.65, 0.15)
    ax.set(xlim=(center[0]-radius, center[0]+radius), ylim=(center[1]-radius, center[1]+radius),
           zlim=(center[2]-radius, center[2]+radius), xlabel='Torso x [m]',
           ylabel='Torso y [m]', zlabel='Torso z [m]', title='Pinocchio: G1 left-arm IK')
    ax.set_box_aspect([1, 1, 1]); ax.legend(fontsize=8)
    ax2 = fig.add_subplot(122)
    for method, result in results.items():
        ax2.semilogy(result['costs'], label=method)
    ax2.set(xlabel='Iteration', ylabel='Scaled task residual [m]', title='Same target and initial configuration')
    ax2.grid(True, which='both', alpha=0.25); ax2.legend()
    fig.tight_layout()
    return fig


class G1Viewer:
    """MuJoCo visualization only: mj_forward, never mj_step or motor commands."""
    def __init__(self):
        import mujoco
        self.mj = mujoco
        self.model = mujoco.MjModel.from_xml_path(str(MODEL_DIR / 'g1_classroom.xml'))
        self.data = mujoco.MjData(self.model)
        # Explicit name mapping; MuJoCo and Pinocchio joint orders may differ.
        joint_ids = [mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, n) for n in JOINT_NAMES]
        if min(joint_ids) < 0:
            raise ValueError('An arm joint is missing from the MuJoCo model')
        self.iq = np.array([self.model.jnt_qposadr[j] for j in joint_ids])
        self.iv = np.array([self.model.jnt_dofadr[j] for j in joint_ids])
        self.joint_ids = np.array(joint_ids)
        self.site_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, 'left_tool_site')
        body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, 'target')
        self.mocap_id = self.model.body_mocapid[body_id]

    def update(self, q, target, rotation=None):
        self.data.qpos[:] = self.model.qpos0  # keep non-arm joints fixed, even after GUI edits
        self.data.qpos[self.iq] = q
        self.data.qvel[:] = 0
        self.data.mocap_pos[self.mocap_id] = ARM.world_T_torso.act(np.asarray(target))
        R = ARM.world_T_torso.rotation @ (np.eye(3) if rotation is None else rotation)
        xyzw = pin.Quaternion(R).coeffs()
        self.data.mocap_quat[self.mocap_id] = xyzw[[3, 0, 1, 2]]  # MuJoCo uses wxyz
        self.mj.mj_forward(self.model, self.data)

    def camera(self):
        camera = self.mj.MjvCamera()
        camera.lookat[:] = [0.0, 0.0, 0.85]
        camera.distance = 2.4
        camera.azimuth = 135
        camera.elevation = -15
        return camera

    def render(self, q, target, rotation=None):
        self.update(q, target, rotation)
        with self.mj.Renderer(self.model, height=720, width=960) as renderer:
            renderer.update_scene(self.data, camera=self.camera())
            return renderer.render().copy()


def run_viewer(target, method='dls', target_rotation=None, damping=0.03, max_seconds=None):
    import mujoco.viewer
    import sys
    if sys.platform == 'darwin' and 'mjpython' not in sys.executable:
        print('macOS: launch this script with mjpython if the passive viewer cannot start.')
    bridge = G1Viewer()
    events = queue.SimpleQueue()
    q = Q_START.copy()
    target = np.asarray(target).copy()
    initial_target = target.copy()
    movements = {ord('I'): (0, 1), ord('K'): (0, -1), ord('J'): (1, 1),
                 ord('L'): (1, -1), ord('U'): (2, 1), ord('O'): (2, -1)}
    methods = {ord('1'): 'transpose', ord('2'): 'pinv', ord('3'): 'dls'}
    print('Viewer: I/K = +/- torso x; J/L = +/- torso y; U/O = +/- torso z (2 cm).')
    print('1 = transpose; 2 = pseudoinverse; 3 = DLS. Space = reset arm and target.')
    print('Target is orange; tool point is green. Close the window to exit.')
    print('Kinematic display: base fixed, no physics stepping, no collision checking.')
    bridge.update(q, target, target_rotation)
    start = time.monotonic()
    iterations = 0
    active = True
    with mujoco.viewer.launch_passive(bridge.model, bridge.data, key_callback=events.put) as viewer:
        camera = bridge.camera()
        with viewer.lock():
            viewer.cam.lookat[:] = camera.lookat
            viewer.cam.distance = camera.distance
            viewer.cam.azimuth = camera.azimuth
            viewer.cam.elevation = camera.elevation
        while viewer.is_running() and (max_seconds is None or time.monotonic()-start < max_seconds):
            tick = time.monotonic()
            while not events.empty():
                key = events.get()
                if key in movements:
                    axis, direction = movements[key]
                    target[axis] += direction*0.02
                elif key in methods:
                    method = methods[key]
                    q = Q_START.copy()  # compare methods from the same initial arm state
                elif key == 32:
                    q, target = Q_START.copy(), initial_target.copy()
                else:
                    continue
                iterations, active = 0, True
                print(f'{method}: target {np.round(target, 3)} m in torso_link')
            if active:
                result = solve_ik(target, q, method=method, damping=damping, max_iter=1,
                                  target_rotation=target_rotation)
                q = result['q']
                iterations += result['iterations']
                if result['status'] != 'iteration_limit' or iterations >= 400:
                    active = False
                    print(f"{method}: {result['status']}; {iterations} updates; "
                          f"{1000*result['errors'][-1]:.3f} mm; "
                          f"{np.rad2deg(result['orientation_errors'][-1]):.3f} deg")
            with viewer.lock():
                bridge.update(q, target, target_rotation)
            viewer.sync()
            time.sleep(max(0, 1/60 - (time.monotonic()-tick)))


def validate_models(samples=20):
    """Cross-check independent FK/Jacobians and exact pose-residual derivatives."""
    bridge = G1Viewer()
    rng = np.random.default_rng(7)
    max_pose, max_jac, max_fd = 0.0, 0.0, 0.0
    assert np.allclose(bridge.model.jnt_range[bridge.joint_ids], np.c_[LOWER, UPPER])
    for _ in range(samples):
        q = rng.uniform(LOWER+0.05, UPPER-0.05)
        pose = ARM.forward(q)
        bridge.update(q, pose.translation)
        world_pose = ARM.world_T_torso * pose
        max_pose = max(max_pose, np.max(np.abs(world_pose.translation-bridge.data.site_xpos[bridge.site_id])),
                       np.max(np.abs(world_pose.rotation-bridge.data.site_xmat[bridge.site_id].reshape(3, 3))))
        jp, jr = np.zeros((3, bridge.model.nv)), np.zeros((3, bridge.model.nv))
        bridge.mj.mj_jacSite(bridge.model, bridge.data, jp, jr, bridge.site_id)
        R = ARM.world_T_torso.rotation.T
        mj_jac = np.vstack((R @ jp[:, bridge.iv], R @ jr[:, bridge.iv]))
        max_jac = max(max_jac, np.max(np.abs(mj_jac-ARM.jacobian(q))))
        goal = ARM.forward(np.clip(q+0.25, LOWER, UPPER))
        h = 1e-6
        numeric = np.column_stack([
            -(task(q+h*np.eye(7)[i], goal.translation, goal.rotation)[0]
              - task(q-h*np.eye(7)[i], goal.translation, goal.rotation)[0])/(2*h)
            for i in range(7)])
        analytic = task(q, goal.translation, goal.rotation)[1]
        max_fd = max(max_fd, np.max(np.abs(numeric-analytic)))
    assert max_pose < 1e-7, max_pose
    assert max_jac < 1e-7, max_jac
    assert max_fd < 1e-7, max_fd
    print(f'Pinocchio/MuJoCo pose difference: {max_pose:.3e}')
    print(f'Pinocchio/MuJoCo Jacobian difference: {max_jac:.3e}')
    print(f'Pose-residual finite-difference discrepancy: {max_fd:.3e}')
    print(f'PASS: {samples} configurations, named joint mapping, limits, FK and Jacobians.')
    return dict(pose=max_pose, jacobian=max_jac, finite_difference=max_fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--viewer', action='store_true', help='Open viewer even when also saving a figure')
    parser.add_argument('--save', metavar='PNG', help='Save a convergence plot without opening a window')
    parser.add_argument('--render', metavar='PNG', help='Save a MuJoCo image; requires working OpenGL')
    parser.add_argument('--check', action='store_true', help='Check both models without a graphics context')
    parser.add_argument('--pose', action='store_true', help='Also match the orientation from Q_TARGET')
    parser.add_argument('--target', nargs=3, type=float, metavar=('X', 'Y', 'Z'), help='Position in torso_link [m]')
    parser.add_argument('--method', choices=['transpose', 'pinv', 'dls'], default='dls')
    parser.add_argument('--damping', type=float, default=0.03, help='DLS damping for the interactive viewer')
    parser.add_argument('--max-seconds', type=float, help='Close the viewer automatically after this duration')
    args = parser.parse_args()
    if args.damping <= 0:
        parser.error('--damping must be positive')
    if args.max_seconds is not None and args.max_seconds <= 0:
        parser.error('--max-seconds must be positive')
    goal = ARM.forward(Q_TARGET)
    target = np.array(args.target) if args.target is not None else goal.translation.copy()
    rotation = goal.rotation.copy() if args.pose else None
    if args.check:
        validate_models()
    if args.save or args.render:
        import matplotlib
        matplotlib.use('Agg')
        target, results = compare(target, rotation)
        if args.save:
            plot_results(target, results).savefig(args.save, dpi=160)
        if args.render:
            import matplotlib.pyplot as plt
            plt.imsave(args.render, G1Viewer().render(results[args.method]['q'], target, rotation))
    if args.viewer or not (args.check or args.save or args.render):
        run_viewer(target, args.method, rotation, args.damping, args.max_seconds)


if __name__ == '__main__':
    main()
